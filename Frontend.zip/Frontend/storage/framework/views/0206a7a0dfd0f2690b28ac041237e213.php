<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Dashboard</title>
    <link rel="stylesheet" href="user.css">

<style>


body {
    margin: 0;
    font-family: Arial, sans-serif;
    display: flex;
}

.sidebar {
    width: 200px;
    background-color: #800000;
    color: white;
    display: flex;
    flex-direction: column;
    align-items: center;
    padding: 20px 0;
}

.section {
    margin-bottom: 20px;
    color: limegreen;
    font-size: 18px;
    font-weight: bold;
}

.nav-button {
    background-color: #800000;
    color: white;
    border: none;
    padding: 15px;
    width: 100%;
    text-align: left;
    cursor: pointer;
    font-size: 18px;
}

.nav-button:hover {
    background-color: #660000;
}

.main-content {
    flex-grow: 1;
    padding: 20px;
    background-color: #f4f4f4;
}

.header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    background-color: #800000;
    color: limegreen;
    padding: 10px 20px;
}

.user-button {
    background-color: green;
    color: white;
    border: none;
    padding: 10px 20px;
    cursor: pointer;
    font-size: 18px;
}

.user-table-container {
    margin: 20px 0;
}

.user-table {
    width: 100%;
    border-collapse: collapse;
    margin-bottom: 20px;
    background-color: white;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
}

.user-table th,
.user-table td {
    border: 1px solid #ddd;
    padding: 8px;
    text-align: left;
}

.user-table th {
    background-color: #f4f4f4;
    font-weight: bold;
}

.user-table tbody tr:hover {
    background-color: #f1f1f1;
}

.buttons {
    display: flex;
    gap: 10px;
}

.action-button {
    padding: 10px 20px;
    font-size: 16px;
    cursor: pointer;
}

#addUser {
    background-color: #4CAF50;
    color: white;
    border: none;
}

#exportList {
    background-color: #008CBA;
    color: white;
    border: none;
}

.styled-link{
    width: 100px;
    height: 30px;
    text-decoration: none;
    color: rgb(255, 255, 255);
    border-radius: 30px;
    text-align: center;
    font-weight: bold;
    padding-top: 10px;
    
}

aside {
    grid-area: aside;
    background-color: #800000;
    padding: 20px;
}

.menu {
    list-style-type: none;
    padding: 0;
}

.menu li {
    background-color: darkred;
    color: white;
    padding: 10px;
    margin-bottom: 5px;
    text-align: center;
    cursor: pointer;
}

</style>


</head>
<body>

    <div class="sidebar">
        <aside>
            <ul class="menu">
                <li>
                    <a class="nav-link" href="dashboard.html" style="color: limegreen; text-decoration: none; font-size: 20px; font-weight: bold;">Dashboard</a>
                </li>
                <li>
                    <a class="nav-link" href="revenue.html" style="color: limegreen; text-decoration: none; font-size: 20px; font-weight: bold;">Revenue</a>
                </li>
                <li>
                    <a class="nav-link" href="templateb.html" style="color: limegreen; text-decoration: none; font-size: 20px; font-weight: bold;">Template</a>
                </li>
                <li>
                    <a class="nav-link" href="message.html" style="color: limegreen; text-decoration: none; font-size: 20px; font-weight: bold;">Message</a>
                </li>
            </ul>
        </aside>
    </div>
    <div class="main-content">
        <div class="header">
            <h1>USER</h1>
            <a href="/user" class="styled-link"
                            style="background-color: limegreen;">User</a>
        </div>
        <div class="user-table-container">
            <h2>Users</h2>
                
            <table class="user-table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Last Name</th>
                        <th>First Name</th>
                        <th>Gender</th>
                        <th>Email</th>
                        <th>Edit</th>
                        <th>Delete User</th>
                    </tr>
                </thead>
               
                <tbody>
                    <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($item->user_id); ?></td>
                            <td><?php echo e($item->first_name); ?></td>
                            <td><?php echo e($item->last_name); ?></td>
                            <td><?php echo e($item->gender); ?></td>
                            <td><?php echo e($item->email); ?></td>
                            <td> <a href="<?php echo e(url('user/'.$item->user_id.'/edit')); ?>">Edit</a> </td>
                            <td> <a href="<?php echo e(url('user/'.$item->user_id.'/delete')); ?>">Delete</a> </td>

                        </tr>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
               
            </table>
            <div class="buttons">
                <button class="action-button" id="addUser">Add User</button>
                <button class="action-button" id="exportList">Export List</button>
            </div>
        </div>
    </div>
  
</body>
</html>
<?php /**PATH /Users/tangchhannon/Documents/Semester4/CS262/FinalProject/Last-final-web/LoginPage/app/resources/views/backend/user.blade.php ENDPATH**/ ?>