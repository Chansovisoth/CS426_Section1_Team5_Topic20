<?php $__env->startSection('content'); ?>

<style>

.sidebar{
    background-color: rgb(137, 45, 45);
    color: white;
    
}

input{
    height: 65px;
    width: 43%;
    border-radius: 20px;
    border: none;
    background-color: rgb(206, 204, 204);
    padding: 15px;
    
}

.styled-link{
    width: 150px;
    height: 45px;
    text-decoration: none;
    color: rgb(255, 255, 255);
    border-radius: 30px;
    padding: 10px;
    text-align: center;
    font-weight: bold;
    margin-top: 4%;
    margin-left: 6%;
    
}
</style>

        <!-- Left -->
        <div class="row">
            <div class="col-7">
                <div class="left">
                    <h1
                        style="text-align: center; font-weight: bold; font-family: 'Times New Roman', Times, serif; font-size: 50px; margin-top: 10%;">
                        Add your <b style="color: orange;">experience</b></h1>
                    <!-- Job -->
                    <div class="name" style="padding-top: 40px; margin-left: 12%;">
                        <input type="text" placeholder="Job-Title" style="width: 90%;">
                    </div>
                    <!-- Date -->
                    <div class="country" style="padding-top: 30px; margin-left: 12%; ">
                        <input type="text" placeholder="Start-Date" style="margin-right: 30px;">
                        <input type="text" placeholder="End-Date">
                    </div>
                    <!-- Details -->
                    <div class="phone" style="padding-top: 30px; margin-left: 12%;">
                        <input type="text" placeholder="Add-more-Details" style="width: 90%; height: 120px;">
                    </div>
                    <div class="d-flex justify-content-center align-item-center gap-3">
                        <a href="/education" class="styled-link"
                            style="background-color: orange;">Next</a>
                    </div>

                </div>
            </div>
            <!-- Right -->
            <div class="col-5" style="background-color: rgb(157, 75, 75); height: 800px;">
                <div class="image">
                    <img src="contact.jpg" alt="" class="rounded mx-auto d-block" style="width: 75%; margin-top: 70px;">
                </div>
            </div>
        </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/tangchhannon/Documents/Semester4/CS262/FinalProject/LoginPage/app/resources/views/experience.blade.php ENDPATH**/ ?>