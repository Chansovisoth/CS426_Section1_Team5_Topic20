<?php $__env->startSection('content'); ?>

<style>
    img {
        width: 350px;
        margin-top: 40px;
        margin-left: 50px;
        border: 3px solid black;
    }

    .sidebar {
        background-color: rgb(137, 45, 45);
        color: white;
    }

    .styled-link {
        width: 200px;
        height: 45px;
        text-decoration: none;
        color: rgb(255, 255, 255);
        border-radius: 30px;
        padding: 10px;
        text-align: center;
        font-weight: bold;
    }

    .orange {
        background: rgb(137, 45, 45);
    }
</style>

<!-- Select-T -->
<div class="select">
    <h1 style="text-align: center; font-weight: bold; font-family: 'Times New Roman', Times, serif; line-height: 40px; margin-top: 30px;">Select a template for <br> <b style="color: orange;">your design</b></h1>
</div>
<hr style="width: 1100px; margin-left: 300px;">

<!-- Template -->

<div class="container">
    <form action="<?php echo e(route('template.select')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="row">
            <div class="col-sm text-center">
                <label>
                    <input type="radio" name="tem_id" value="1">
                    <img src="empty-pic5.jpg" alt="Template 1" class="img-thumbnail">
                </label>
            </div>
            <div class="col-sm text-center">
                <label>
                    <input type="radio" name="tem_id" value="2">
                    <img src="empty-pic4(2).png" alt="Template 2" class="img-thumbnail">
                </label>
            </div>
            <div class="col-sm text-center">
                <label>
                    <input type="radio" name="tem_id" value="3">
                    <img src="empty-pic3.jpg" alt="Template 3" class="img-thumbnail">
                </label>
            </div>
        </div>
        <hr style="width: 1100px; margin: 20px auto;">
        <p style="text-align: center; font-size: 20px;">Choose the different color of your template</p>
        <div class="d-flex justify-content-center align-items-center gap-3">
            <button type="submit" class="btn btn-primary orange">Select this template</button>
        </div>
    </form>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Semester 4\CS 262\LoginPage 2\LoginPage\app\resources\views/template.blade.php ENDPATH**/ ?>