

<?php $__env->startSection('content'); ?>
<style>
    .sidebar{
    background-color: rgb(137, 45, 45);
    color: white;
    
}

.name input{
    height: 65px;
    width: 45%;
    border-radius: 20px;
    border: none;
    background-color: rgb(206, 204, 204);
    padding: 15px;
    
}


button{
    width: 130px;
    height: 45px;
    border: none;
    background-color: orange;
    color: white;
    font-family: 'Times New Roman', Times, serif;
    
}

b{
    color: rgb(255, 167, 3);
}

textarea{
    border-radius: 20px;
    border: none;
    background-color: rgb(206, 204, 204);
    padding: 15px;
    height: 130px;
    width: 400px;
}

.expertise textarea{
    height: 65px;
    width: 45%;
    border-radius: 20px;
    border: none;
    background-color: rgb(206, 204, 204);
    padding: 15px;
}

.name textarea{
    height: 65px;
    width: 45%;
    border-radius: 20px;
    border: none;
    background-color: rgb(206, 204, 204);
    padding: 15px;
}

</style>

    <div class="nav-bar" style="height: 60px;">
        <nav class="navbar navbar-expand-lg fixed-top" style="background-color: rgb(137, 45, 45);">
            <div class="container">
                <a class="navbar-brand fs-4" href="#" style="color: white; font-family: 'Times New Roman', Times, serif;">SMOS <b style="color: orange;">COMPANY</b></a>
                <button class="navbar-toggler" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasNavbar" aria-controls="offcanvasNavbar" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="sidebar offcanvas offcanvas-start" tabindex="-1" id="offcanvasNavbar" aria-labelledby="offcanvasNavbarLabel">
                    <div class="offcanvas-header text-white border-bottom">
                        <h5 class="offcanvas-title" id="offcanvasNavbarLabel">SMOS COMPANY</h5>
                        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="offcanvas" aria-label="Close"></button>
                    </div>
                    <div class="offcanvas-body">
                        <ul class="navbar-nav justify-content-end flex-grow-1 pe-3">
                            <li class="nav-item">
                                <a class="nav-link active" aria-current="page" href="front.html" style="color: white;">Home</a>
                            </li>
                            <li class="nav-item mx-2">
                                <a class="nav-link" href="profile.html" style="color: white;">Profile</a>
                            </li>
                            <li class="nav-item mx-2">
                                <a class="nav-link" href="#contact" style="color: white;">Contact Us</a>
                            </li>
                        </ul>
                        <div class="d-flex justify-content-center align-item-center gap-3">
                            <a href="login.html" class="text-white text-decoration-none px-3 py-1 rounded-2" style="background-color: orange;">Login</a>
                        </div>
                    </div>
                </div>
            </div>
        </nav>
    </div>

    <form id="headerForm">
        <div class="row">
            <div class="col-3" style="background-color: rgb(255, 255, 255);">
                <h1 style="text-align: center; margin-top: 20px; font-weight: bold; font-family: 'Times New Roman', Times, serif;">Add your <b>photo</b></h1>
                <img src="cam2.png" alt="" style="width: 40%; margin-top: 4%; margin-left: 28%;">
                <div class="form-group">
                    <input type="file" id="photo" style="margin-top: 6%; margin-left: 22%;" onchange="previewPhoto(event)">
                </div>
            </div>

            <div class="col-5" style="background-color: rgb(255, 255, 255); border: 2px solid rgb(137, 45, 45); border-bottom: none; height: 900px;">
                <h1 style="text-align: center; margin-top: 20px; font-weight: bold; font-family: 'Times New Roman', Times, serif;">Add your <b>info</b></h1>
                <div class="name" style="padding-top: 20px; margin-left: 5%;">
                    <input type="text" name="firstName" id="firstName" placeholder="Name" required style="margin-right: 30px;">
                    <input type="text" name="phoneNumber" id="phoneNumber" placeholder="Phone-number" required>
                </div>
                <div class="name" style="padding-top: 20px; margin-left: 5%;">
                    <input type="text" name="country" id="country" placeholder="Address" required style="margin-right: 30px;">
                    <input type="text" name="date" id="date" placeholder="Start-End-Date" required>
                </div>
                <div class="name" style="padding-top: 20px; margin-left: 5%;">
                    <input type="email" name="email" id="email" placeholder="Email" required style="margin-right: 30px;">
                    <input type="text" name="graduation" id="graduation" placeholder="Year-of-Graduation" required>
                </div>
                <div class="name" style="padding-top: 20px; margin-left: 5%;">
                    <input type="text" name="jobTitle" id="jobTitle" placeholder="Job-Title" required style="margin-right: 30px;">
                    <input type="text" name="university" id="university" placeholder="University" required style="margin-right: 30px;">
                </div>
                <button type="button" onclick="submitForm()" style="margin-left: 40%; margin-top: 5%; border-radius: 15px; font-size: 20px; font-weight: bold;">Next</button>
            </div>

            <div class="col-4" style="background-color: rgb(255, 255, 255);">
                <h1 style="text-align: center; margin-top: 20px; font-weight: bold; font-family: 'Times New Roman', Times, serif;">Add more <b>details</b></h1>
                <div class="summary" style="padding-top: 3%; margin-left: 12%;">
                    <textarea id="QInput" name="QInput" placeholder="Add-your-Qualification" required></textarea>
                </div>
                <div class="summary" style="padding-top: 20px; margin-left: 12%;">
                    <textarea name="summary" id="summary" placeholder="Add-your-Profile" required></textarea>
                </div>
                <div class="summary" style="padding-top: 20px; margin-left: 12%;">
                    <textarea name="dEducation" id="dEducation" placeholder="Add-More-Details-Education" required></textarea>
                </div>
                <div class="summary" style="padding-top: 20px; margin-left: 12%;">
                    <textarea name="dExperience" id="dExperience" placeholder="Add-More-Details-Experience" required></textarea>
                </div>
            </div>
        </div>
    </form>

    <script>
        function submitForm() {
            var form = document.getElementById('headerForm');
            var formData = new FormData(form);

            var data = {};
            formData.forEach(function(value, key) {
                data[key] = value;
            });

            // Store qualifications separately as an array
            var qualifications = document.getElementById('QInput').value.split(',');

            localStorage.setItem('formData', JSON.stringify(data));
            localStorage.setItem('qlist', JSON.stringify(qualifications));

            window.location.href = 'template3.html';
        }

        function previewPhoto(event) {
            var reader = new FileReader();
            reader.onload = function () {
                var output = document.getElementById('photo-preview');
                output.src = reader.result;
            };
            reader.readAsDataURL(event.target.files[0]);
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/tangchhannon/Documents/Semester4/CS262/FinalProject/Last-final-web/LoginPage/app/resources/views/input3.blade.php ENDPATH**/ ?>