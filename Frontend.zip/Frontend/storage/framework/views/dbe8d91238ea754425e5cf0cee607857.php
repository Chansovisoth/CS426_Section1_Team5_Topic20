<?php $__env->startSection('content'); ?>

<style>

.sidebar{
    background-color: rgb(137, 45, 45);
    color: white;
    
}

input{
    height: 65px;
    width: 43%;
    border-radius: 20px;
    border: none;
    background-color: rgb(206, 204, 204);
    padding: 15px;
    
}


</style>
        <!-- Left -->
        <div class="row">
            <div class="col-7">
                <div class="left">
                    <h1
                        style="text-align: center; font-weight: bold; font-family: 'Times New Roman', Times, serif; font-size: 50px; margin-top: 10%;">
                        Add your <b style="color: orange;">summary</b></h1>
                    
                    <!-- Details -->
                    <div class="phone" style="padding-top: 20px; margin-left: 12%;">
                        <p style="color: gray; padding-left: 10px; font-size: 20px;">Add-more-details</p>
                        <input type="text"style="width: 90%; height: 300px;">
                    </div>
                    <button
                        style="background-color: orange; color: white; width: 150px; height: 50px; border: none; border-radius: 25px; margin-left: 45%; margin-top: 40px; font-weight: bold; font-size: 20px;">Next</button>

                </div>
            </div>
            <!-- Right -->
            <div class="col-5" style="background-color: rgb(157, 75, 75); height: 800px;">
                <div class="image">
                    <img src="contact.jpg" alt="" class="rounded mx-auto d-block" style="width: 75%; margin-top: 70px;">
                </div>
            </div>
        </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/tangchhannon/Documents/Semester4/CS262/FinalProject/LoginPage/app/resources/views/summary.blade.php ENDPATH**/ ?>