<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Template 2</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" integrity="sha512-SnH5WK+bZxgPHs44uWIX+LLJAJ9/2PkPKZ5QiAj6Ta86w+fsb2TkcmfRyVX3pBnMFcV7oQPJkl9QevSCWr3W6A==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap" rel="stylesheet" />
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;700&display=swap" rel="stylesheet" />
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;700&display=swap" rel="stylesheet" />
    <link href="https://fonts.googleapis.com/css2?family=Roboto+Slab:wght@400;700&display=swap" rel="stylesheet" />
    <link href="https://fonts.googleapis.com/css2?family=Lexend:wght@100..900&family=Sora:wght@100..800&display=swap" rel="stylesheet" />
    <style>
      body {
        font-family: "Lexend", sans-serif;
        margin: 0;
        padding: 0;
        background-color: #f4f4f4;
      }
      .sidebar {
        background: #1d1d1d;
        color: #fff;
        padding: 20px;
        text-align: left;
        min-height: 100vh; /* Ensure the sidebar stretches to the full height */
      }
      .sidebar img {
        border-radius: 50%;
        width: 193px;
        height: 193px;
        object-fit: cover;
        margin: 20px auto;
        display: block;
        border: 5px solid #fff; /* Adding a white border */
      }
      h2 {
        border-bottom: 2px solid #1f1f1f;
        padding-bottom: 5px;
        margin-bottom: 10px;
        font-weight: bold;
      }
      .col-md-8 {
        padding: 35px;
      }
      .list-unstyled {
        list-style-type: none;
        padding: 0;
      }
      header {
        display: flex;
        flex-direction: column;
        align-items: center;
        text-align: center;
      }
      header h1 {
        font-family: "lexend", sans-serif;
        margin: 0;
        padding: 0;
        font-weight: bold;
      }
      header h2 {
        font-family: "Open Sans", sans-serif;
        margin: 0;
        padding: 0;
      }
      .contact-info {
        margin-top: 20px;
      }
      .list-styled li {
        margin-bottom: 5px;
      }
      .languages {
        margin-top: 20px;
      }
    h3 {
        border-bottom: 2px solid #ffffff;
        padding-bottom: 5px;
        margin-bottom: 10px;
        font-weight: bold;
      }
      h6 {
        font-size: 20px;
        margin-top: 5px;
        margin-bottom: 5px;
      }
      .col-md-4 .sidebar {
        padding: 
      }
    </style>
  </head>
  <body>
    <div class="container my-5">
      <form action="<?php echo e(route('store_cv_info')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="user_resume_id" value="<?php echo e($user_resume_id); ?>">
      
        <div class="row">
          <div class="col-md-4 sidebar">
            <img src="/picture/edited-4202.jpg" alt="Claudia Alves" />
            <h3>CONTACT</h3>
            <div class="contact-info">
              <p><i class="fa-solid fa-phone"></i> <input type="text" name="phone" value="+123-456-7890"></p>
              <p><i class="fa-regular fa-envelope"></i> <input type="text" name="email" value="hello@reallygreatsite.com"></p>
              <p><i class="fa-solid fa-globe"></i> <input type="text" name="website" value="www.reallygreatsite.com"></p>
              <p><i class="fas fa-map-marker-alt"></i> <input type="text" name="address" value="123 Anywhere ST., Any City"></p>
            </div>
            <div class="skills mt-4">
              <h3>Skills</h3>
              <ul class="list-styled">
                <li><input type="text" name="skill1" value="Team Work"></li>
                <li><input type="text" name="skill2" value="Time Management"></li>
                <li><input type="text" name="skill3" value="Leadership"></li>
                <li><input type="text" name="skill4" value="Verbal & Written Communication"></li>
              </ul>
            </div>
            <div class="languages mt-4">
              <h3>Language</h3>
              <ul class="list-styled">
                <li><input type="text" name="language1" value="English"></li>
                <li><input type="text" name="language2" value="French"></li>
                <li><input type="text" name="language3" value="Chinese"></li>
                <li><input type="text" name="language4" value="Spanish"></li>
                <li><input type="text" name="language5" value="Hindi"></li>
              </ul>
            </div>
          </div>
          <div class="col-md-8">
            <header>
              <h1><input type="text" name="name" value="CLAUDIA ALVES"></h1>
              <h6><input type="text" name="position" value="CHIEF EXCLUSIVE OFFICE"></h6>
            </header>
            <section id="professionalprofile" class="mt-4">
              <h2>PROFESSIONAL PROFILE</h2>
              <p>
                <textarea name="professional_profile">I am a growth hacker with 4+ years of experience in sales and marketing in the US market. Creative, sharp-minded person with leadership & coaching skills. Strong time-management skills and work ethic. Revenue- and results-driven.</textarea>
              </p>
            </section>
            <section id="workexperience" class="mt-4">
              <h2>WORK EXPERIENCE</h2>
              <div class="mb-3">
                <h4><input type="text" name="job_title1" value="CEO & President"></h4>
                <p><em><input type="text" name="job_duration1" value="April 2030 - June 2033"></em></p>
                <p>
                  <textarea name="job_description1">Effectively managed team of over 270 employees in 12 locations in 3 countries. Oversaw executive leadership, company training, and public relations with media. Developed intensive, ambitious business strategies, short-term goals, and long-term objectives. Spearheaded overhaul of various underperforming departments to reduce stagnation and increase growth and productivity. Fostered change in company culture to be more open, transparent, and accountable.</textarea>
                </p>
              </div>
              <div>
                <h4><input type="text" name="job_title2" value="Head Manager"></h4>
                <p><em><input type="text" name="job_duration2" value="January 2034 - April 2035"></em></p>
                <p>
                  <textarea name="job_description2">Led team of 50 employees in a busy retail research and analysis firm. Oversaw the day-to-day operations, including meeting with team leaders and auditing activity. Implemented the push towards Artificial Intelligence and Machine Learning to aid in exponentially larger analysis tasks able to be completed. Ensured company was meeting all legal requirements and local regulations. Pushed for constant growth among management team and general staff, alike.</textarea>
                </p>
              </div>
            </section>
            <section id="education" class="mt-4">
              <h2>EDUCATION</h2>
              <div class="mb-3">
                <h4><input type="text" name="degree1" value="Bachelor of Business Bachelor"></h4>
                <p><em><input type="text" name="degree_duration1" value="April 2030 - June 2033"></em></p>
              </div>
              <div>
                <h4><input type="text" name="degree2" value="Master of Business Administration Bachelor"></h4>
                <p><em><input type="text" name="degree_duration2" value="January 2034 - April 2035"></em></p>
              </div>
            </section>
            <button type="submit" class="btn btn-primary mt-4">Save</button>
          </div>
        </div>
      </form>
    </div>
    <script src="https://kit.fontawesome.com/a076d05399.js"></script>
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
  </body>
</html>
<?php /**PATH /Users/tangchhannon/Documents/Semester4/CS262/FinalProject/Last-final-web-display-final-cv/LoginPage/app/resources/views/temptest.blade.php ENDPATH**/ ?>