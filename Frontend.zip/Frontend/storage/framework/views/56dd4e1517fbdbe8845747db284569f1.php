

<?php $__env->startSection('content'); ?>


<div class="container my-5">
    <div class="row">
        <div class="col-md-4 sidebar">
            <img src="camera.png" alt="Profile Picture" />

            <!-- CONTACT -->
            <h3>CONTACT</h3>
            <div class="contact-info">
                <p><i class="fa-solid fa-phone"></i><?php echo e($userResume->user->phone_number); ?></p>
                <p><i class="fa-regular fa-envelope"></i><?php echo e($userResume->user->email); ?></p>
                <p><i class="fas fa-map-marker-alt"></i><?php echo e($userResume->user->address); ?></p>
            </div>

            <!-- SKILLS -->
            <div class="skills mt-4">
                <h3>Skills</h3>
                <ul>
                    <?php $__currentLoopData = $userResume->cvInfos->where('field_name', 'skills'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cvInfo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $skills = explode(',', $cvInfo->field_value);
                        ?>
                        <?php $__currentLoopData = $skills; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e(trim($skill)); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>

            <!-- LANGUAGES -->
            <div class="languages mt-4">
                <h3>Languages</h3>
                <ul>
                    <?php $__currentLoopData = $userResume->cvInfos->where('field_name', 'languages'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cvInfo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $languages = explode(',', $cvInfo->field_value);
                        ?>
                        <?php $__currentLoopData = $languages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $language): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e(trim($language)); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        </div>

        <!-- MAIN CONTENT -->
        <div class="col-md-8">
            <header>
                <div style="display: flex;">
                    <h1><?php echo e($userResume->user->first_name); ?></h1>
                    <h1 style="padding-left: 10px;"><?php echo e($userResume->user->last_name); ?></h1>
                </div>
            </header>

            <!-- PROFESSIONAL PROFILE -->
            <section id="professionalProfile" class="mt-4">
                <h2>PROFESSIONAL PROFILE</h2>
                <p><?php echo e($userResume->cvInfos->where('field_name', 'summary')->first()->field_value ?? ''); ?></p>
            </section>

            <!-- WORK EXPERIENCE -->
            <section id="workExperience" class="mt-4">
                <h2>WORK EXPERIENCE</h2>
                <ul>
                    <?php $__currentLoopData = $userResume->cvInfos->where('field_name', 'job_experience'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cvInfo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($cvInfo->field_value); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </section>

            <!-- EDUCATION -->
            <section id="education" class="mt-4">
                <h2>EDUCATION</h2>
                <ul>
                    <li><?php echo e($userResume->cvInfos->where('field_name', 'university')->first()->field_value ?? ''); ?></li>
                    <li><?php echo e($userResume->cvInfos->where('field_name', 'qualification')->first()->field_value ?? ''); ?></li>
                    <li><?php echo e($userResume->cvInfos->where('field_name', 'major')->first()->field_value ?? ''); ?></li>
                    <li><?php echo e($userResume->cvInfos->where('field_name', 'graduation_year')->first()->field_value ?? ''); ?></li>
                    <?php $__currentLoopData = $userResume->cvInfos->where('field_name', 'education_details'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cvInfo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($cvInfo->field_value); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </section>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/tangchhannon/Documents/Semester4/CS262/FinalProject/Last-final-web/LoginPage/app/resources/views/template2.blade.php ENDPATH**/ ?>