<?php $__env->startSection('content'); ?>
<style>
    .sidebar {
        background-color: rgb(137, 45, 45);
        color: white;
    }

    .profile-info {
        width: 55%;
    }

    .info-field {
        margin-bottom: 15px;
        text-align: left;
    }

    .info-field label {
        display: block;
        color: #888;
        margin-bottom: 5px;
    }

    .info-field input {
        width: 100%;
        padding: 8px;
        border: 1px solid #ddd;
        border-radius: 4px;
        background-color: #cecdcd;
    }
</style>

<div class="row">
    <div class="col-5">
        <div class="left">
            <?php if($user->profile_pic): ?>
                <img src="<?php echo e(asset('storage/' . $user->profile_pic)); ?>" style="width: 20%; margin-top: 10%; margin-left: 65%;">
              

            <?php else: ?>
                <img src="camera.png" style="width: 20%; margin-top: 10%; margin-left: 65%;">
            <?php endif; ?>
        </div>
    </div>
    <div class="col-7">
        <div class="profile-info" style="margin-top: 7%;">
            <div class="info-field">
                <label for="first_name">First Name</label>
                <input type="text" id="first_name" value="<?php echo e($user->first_name); ?>" disabled>
            </div>
            <div class="info-field">
                <label for="last_name">Last Name</label>
                <input type="text" id="last_name" value="<?php echo e($user->last_name); ?>" disabled>
            </div>
            <div class="info-field">
                <label for="gender">Gender</label>
                <input type="text" id="gender" value="<?php echo e($user->gender); ?>" disabled>
            </div>
            <div class="info-field">
                <label for="email">Email</label>
                <input type="text" id="email" value="<?php echo e($user->email); ?>" disabled>
            </div>
        </div>



        
        <!-- Form to upload profile picture -->
        <?php if(!$user->profile_pic): ?>
            <!-- Form to upload profile picture -->
            <form action="<?php echo e(route('profile.upload')); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <input type="file" name="profile_pic" accept="image/*">
                <button type="submit">Upload</button>
            </form>
        <?php endif; ?>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/tangchhannon/Documents/Semester4/CS262/FinalProject/Last-final-web/LoginPage/app/resources/views/profile.blade.php ENDPATH**/ ?>