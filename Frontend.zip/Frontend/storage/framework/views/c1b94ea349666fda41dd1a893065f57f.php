

<?php $__env->startSection('content'); ?>

<style>
    .sidebar {
        background-color: rgb(137, 45, 45);
        color: white;
    }

    .name input {
        height: 65px;
        width: 45%;
        border-radius: 20px;
        border: none;
        background-color: rgb(206, 204, 204);
        padding: 15px;
    }

    button {
        width: 130px;
        height: 45px;
        border: none;
        background-color: orange;
        color: white;
        font-family: 'Times New Roman', Times, serif;
        border-radius: 15px;
        font-size: 20px;
        font-weight: bold;
        margin-left: 40%;
        margin-top: 5%;
    }

    b {
        color: rgb(255, 167, 3);
    }

    textarea {
        border-radius: 20px;
        border: none;
        background-color: rgb(206, 204, 204);
        padding: 15px;
        height: 130px;
        width: 95%;
        margin-top: 20px;
    }

    .summary textarea {
        width: 95%;
        margin-top: 20px;
    }
</style>

<form id="headerForm" action="<?php echo e(route('store_cv_info')); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <input type="hidden" name="user_resume_id" value="<?php echo e($user_resume_id); ?>">

    <div class="row">
        <div class="col-3" style="background-color: rgb(255, 255, 255);">
            <?php if($user->profile_pic): ?>
                <img src="<?php echo e(asset('storage/' . $user->profile_pic)); ?>" style="width: 20%; margin-top: 10%; margin-left: 65%;">
            <?php else: ?>
                <img src="camera.png" style="width: 20%; margin-top: 10%; margin-left: 65%;">
            <?php endif; ?>
        </div>

        <div class="col-5" style="background-color: rgb(255, 255, 255); border: 2px solid rgb(137, 45, 45); border-bottom: none; height: 900px;">
            <h1 style="text-align: center; margin-top: 20px; font-weight: bold; font-family: 'Times New Roman', Times, serif;">Add your <b>info</b></h1>
            <div class="name" style="padding-top: 20px; margin-left: 5%;">
                <input type="text" name="first_name" id="first_name" placeholder="First Name" required style="margin-right: 30px;">
                <input type="text" name="last_name" id="last_name" placeholder="Last Name" required>
            </div>
            <div class="name" style="padding-top: 20px; margin-left: 5%;">
                <input type="text" name="address" id="address" placeholder="Address" required style="margin-right: 30px;">
                <input type="text" name="phone_number" id="phone_number" placeholder="Phone Number" required>
            </div>
            <div class="name" style="padding-top: 20px; margin-left: 5%;">
                <input type="email" name="email" id="email" placeholder="Email" required style="margin-right: 30px;">
                <input type="text" name="start_end_date" id="start_end_date" placeholder="Start-End Date" required>
            </div>
            <div class="name" style="padding-top: 20px; margin-left: 5%;">
                <input type="text" name="job_title" id="job_title" placeholder="Job Title" required style="margin-right: 30px;">
                <input type="text" name="qualification" id="qualification" placeholder="Qualification" required>
            </div>
            <div class="name" style="padding-top: 20px; margin-left: 5%;">
                <input type="text" name="university" id="university" placeholder="University" required style="margin-right: 30px;">
                <input type="text" name="graduation_year" id="graduation_year" placeholder="Year of Graduation" required>
            </div>
            <div class="name" style="padding-top: 20px; margin-left: 5%;">
                <input type="text" name="major" id="major" placeholder="Major" required style="width: 95%;">
            </div>
            <div class="expertise" style="padding-top: 20px; margin-left: 5%;">
                <textarea id="languageInput" name="languages" placeholder="Languages (comma-separated)" required></textarea>
            </div>
            <button type="submit">Next</button>
        </div>

        <div class="col-4" style="background-color: rgb(255, 255, 255);">
            <h1 style="text-align: center; margin-top: 20px; font-weight: bold; font-family: 'Times New Roman', Times, serif;">Add more <b>details</b></h1>
            <div class="summary" style="padding-top: 3%; margin-left: 12%;">
                <textarea name="skills" id="skills" placeholder="Skills (comma-separated)" required></textarea>
            </div>
            <div class="summary" style="padding-top: 20px; margin-left: 12%;">
                <textarea name="summary" id="summary" placeholder="Summary" required></textarea>
            </div>
            <div class="summary" style="padding-top: 20px; margin-left: 12%;">
                <textarea name="education_details" id="education_details" placeholder="Additional Education Details" required></textarea>
            </div>
            <div class="summary" style="padding-top: 20px; margin-left: 12%;">
                <textarea name="experience_details" id="experience_details" placeholder="Additional Experience Details" required></textarea>
            </div>
        </div>
    </div>
</form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/tangchhannon/Documents/Semester4/CS262/FinalProject/Last-final-web/LoginPage/app/resources/views/input1.blade.php ENDPATH**/ ?>