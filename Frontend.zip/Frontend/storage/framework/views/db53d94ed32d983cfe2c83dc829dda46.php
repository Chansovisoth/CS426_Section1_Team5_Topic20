<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Template 2</title>
    <link
      href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css"
      rel="stylesheet"
    />
    <link
      href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css"
      rel="stylesheet"
      integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC"
      crossorigin="anonymous"
    />
    <link
      rel="stylesheet"
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"
      integrity="sha512-SnH5WK+bZxgPHs44uWIX+LLJAJ9/2PkPKZ5QiAj6Ta86w+fsb2TkcmfRyVX3pBnMFcV7oQPJkl9QevSCWr3W6A=="
      crossorigin="anonymous"
      referrerpolicy="no-referrer"
    />
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link
      href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap"
      rel="stylesheet"
    />
    <link
      href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;700&display=swap"
      rel="stylesheet"
    />
    <link
      href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;700&display=swap"
      rel="stylesheet"
    />
    <link
      href="https://fonts.googleapis.com/css2?family=Roboto+Slab:wght@400;700&display=swap"
      rel="stylesheet"
    />
    <link
      href="https://fonts.googleapis.com/css2?family=Lexend:wght@100..900&family=Sora:wght@100..800&display=swap"
      rel="stylesheet"
    />
    <style>
      body {
        font-family: "Lexend", sans-serif;
        margin: 0;
        padding: 0;
        background-color: #f4f4f4;
      }
      .sidebar {
        background: #1d1d1d;
        color: #fff;
        padding: 20px;
        text-align: left;
        min-height: 100vh; /* Ensure the sidebar stretches to the full height */
      }
      .sidebar img {
        border-radius: 50%;
        width: 193px;
        height: 193px;
        object-fit: cover;
        margin: 20px auto;
        display: block;
        border: 5px solid #fff; /* Adding a white border */
      }
      h2 {
        border-bottom: 2px solid #1f1f1f;
        padding-bottom: 5px;
        margin-bottom: 10px;
        font-weight: bold;
      }
      .col-md-8 {
        padding: 35px;
      }
      .list-unstyled {
        list-style-type: none;
        padding: 0;
      }
      header {
        display: flex;
        flex-direction: column;
        align-items: center;
        text-align: center;
      }
      header h1 {
        font-family: "lexend", sans-serif;
        margin: 0;
        padding: 0;
        font-weight: bold;
      }
      header h2 {
        font-family: "Open Sans", sans-serif;
        margin: 0;
        padding: 0;
      }
      .contact-info {
        margin-top: 20px;
      }
      .list-styled li {
        margin-bottom: 5px;
      }
      .languages {
        margin-top: 20px;
      }
    h3 {
        border-bottom: 2px solid #ffffff;
        padding-bottom: 5px;
        margin-bottom: 10px;
        font-weight: bold;
      }
      h6 {
        font-size: 20px;
        margin-top: 5px;
        margin-bottom: 5px;
      }
      .col-md-4 .sidebar {
        padding: 
      }
    </style>
  </head>
  <body>
    <div class="container my-5">
      <div class="row">
        <div class="col-md-4 sidebar">
          <img src="/picture/edited-4202.jpg" alt="Claudia Alves" />
          <h3>CONTACT</h3>
          <div class="contact-info">
            <?php $__currentLoopData = $userResume->cvInfos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cvInfo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($cvInfo->field_name === 'phone_number'): ?>
                            <p><i class="fa fa-phone"></i> <?php echo e($cvInfo->field_value); ?></p>
                        <?php endif; ?>
                        <?php if($cvInfo->field_name === 'email'): ?>
                            <p><i class="fa fa-envelope"></i> <?php echo e($cvInfo->field_value); ?></p>
                        <?php endif; ?>
                        <?php if($cvInfo->field_name === 'address'): ?>
                            <p><i class="fa fa-map-marker"></i> <?php echo e($cvInfo->field_value); ?></p>
                        <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  
          </div>
          <?php $__currentLoopData = $userResume->cvInfos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cvInfo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if(in_array($cvInfo->field_name, ['skills', 'languages'])): ?>
                        <div class="other-info mt-4">
                            <div class="title-underline-white"></div>
                            <h5><?php echo e(strtoupper($cvInfo->field_name)); ?></h5>
                            <div class="title-underline-white"></div>
                            <!-- Assuming field_value might need special formatting or handling -->
                            <p><?php echo e($cvInfo->field_value); ?></p>
                        </div>
                    <?php endif; ?>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div class="col-md-8">
          <header>
                    <?php $__currentLoopData = $userResume->cvInfos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cvInfo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($cvInfo->field_name === 'first_name'): ?>
                            <h1> 
                             <span id="firstName"><?php echo e($cvInfo->field_value); ?></span>
                            </h1>
                        <?php endif; ?>
                        <?php if($cvInfo->field_name === 'last_name'): ?>
                            <h1>
                             <span id="firstName"><?php echo e($cvInfo->field_value); ?></span>
                            </h1>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </header>
          <section id="professionalprofile" class="mt-4">

            <h2><?php echo e($userResume->cvInfos->where('field_name', 'job_title')->first()->field_value ?? ''); ?></h2>
          </section>
          <section id="workexperience" class="mt-4">
            <h2>WORK EXPERIENCE</h2>
            <div class="mb-3">
                <h6><?php echo e($userResume->cvInfos->where('field_name', 'job_title')->first()->field_value ?? ''); ?></h6>
                <h6><?php echo e($userResume->cvInfos->where('field_name', 'qualification')->first()->field_value ?? ''); ?></h6>
            </div>
            <div>
                <h6><?php echo e($userResume->cvInfos->where('field_name', 'experience_details')->first()->field_value ?? ''); ?></h6>
                <h6><?php echo e($userResume->cvInfos->where('field_name', 'experience_details')->first()->field_value ?? ''); ?></h6>
            </div>
          </section>
          <section id="education" class="mt-4">
            <h2>EDUCATION</h2>
            <div class="mb-3">
                    <h6><?php echo e($userResume->cvInfos->where('field_name', 'university')->first()->field_value ?? ''); ?></h6>
                    <h6><?php echo e($userResume->cvInfos->where('field_name', 'qualification')->first()->field_value ?? ''); ?></h6>
                    <h6><?php echo e($userResume->cvInfos->where('field_name', 'major')->first()->field_value ?? ''); ?></h6>
                    <h6><?php echo e($userResume->cvInfos->where('field_name', 'graduation_year')->first()->field_value ?? ''); ?></h6>
            </div>
          </section>
        </div>
      </div>
    </div>
    <script src="https://kit.fontawesome.com/a076d05399.js"></script>
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
  </body>
</html>
<?php /**PATH /Users/tangchhannon/Documents/Semester4/CS262/FinalProject/Last-final-web-display-final-cv/LoginPage/app/resources/views/temp2.blade.php ENDPATH**/ ?>