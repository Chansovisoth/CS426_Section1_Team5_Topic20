<?php $__env->startSection('content'); ?>

<style>
    body {
        margin: 0;
        font-family: Arial, sans-serif;
        background-color: #f0f0f0; /* Added background color to body */
    }

    .unique-dashboard {
        display: grid;
        grid-template-areas: 
            'header header'
            'aside main'
            'footer footer';
        grid-template-columns: 1fr 3fr;
        grid-template-rows: auto 1fr auto;
        min-height: 100vh; /* Changed height to min-height for better responsiveness */
    }

    header {
        grid-area: header;
        background-color: #800000;
        color: limegreen;
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 10px;
    }

    .user-button {
        background-color: green;
        color: white;
        border: none;
        padding: 5px 10px;
        cursor: pointer;
        text-decoration: none;
    }

    aside {
        grid-area: aside;
        background-color: #800000;
        padding: 20px;
    }

    .menu {
        list-style-type: none;
        padding: 0;
    }

    .menu li {
        background-color: darkred;
        color: white;
        padding: 15px; /* Increased padding for better touch/click target */
        margin-bottom: 10px;
        text-align: center;
        cursor: pointer;
        border-radius: 5px;
        transition: background-color 0.3s ease;
    }

    .menu li:hover {
        background-color: #5c0e0e;
    }

    .menu li a {
        color: limegreen;
        text-decoration: none;
        font-size: 18px;
        font-weight: bold;
        display: block;
    }

    main {
        grid-area: main;
        padding: 20px;
        display: flex;
        flex-direction: column;
        align-items: center;
        background-color: #fff; /* Added background color to main area */
        border-radius: 10px;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1); /* Added box-shadow for depth */
    }

    .cards {
        display: flex;
        justify-content: space-around;
        width: 100%;
        margin-bottom: 20px;
    }

    .card {
        background-color: #f0f0f0;
        padding: 20px;
        text-align: center;
        box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        flex: 1;
        margin: 0 10px;
        border-radius: 10px;
    }

    .card.pink {
        background-color: #ffe6e6;
    }

    canvas {
        max-width: 100%; /* Ensured canvas is responsive */
        height: auto; /* Adjusted height to maintain aspect ratio */
        margin: 20px 0; /* Added margin for spacing */
    }

    footer {
        grid-area: footer;
        background-color: #800000;
        color: white;
        text-align: center;
        padding: 10px;
    }

    .styled-link {
        display: inline-block;
        padding: 10px 20px;
        color: white;
        background-color: limegreen;
        text-decoration: none;
        border-radius: 5px;
        transition: background-color 0.3s ease;
    }

    .styled-link:hover {
        background-color: #66bb66;
    }
</style>

<div class="unique-dashboard">
    <header>
        <h1>Dashboard</h1>
        <a href="<?php echo e(route('user')); ?>" class="styled-link">User</a>
    </header>
    <aside>
        <ul class="menu">
            <li>
                <a href="<?php echo e(route('admin.dashboard')); ?>">Dashboard</a>
            </li>
            <li>
                <a href="<?php echo e(route('template')); ?>">Template</a>
            </li>
        </ul>
    </aside>
    <main>
        <div class="cards">
            <div class="card pink">
                <span>Downloads</span>
                <h2>168,900</h2>
            </div>
            <div class="card">
                <span>Templates</span>
                <h2>168</h2>
            </div>
        </div>
        <div class="container">
            <h2 style="text-align: center;">Downloads Overview</h2>
            <canvas id="myChart"></canvas>
        </div>
    </main>
    <footer>
        <span>SMOS</span>
    </footer>
</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
    document.addEventListener("DOMContentLoaded", function() {
        const ctx = document.getElementById('myChart').getContext('2d');
        const myChart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: ['Red', 'Blue', 'Yellow', 'Green', 'Purple', 'Orange'],
                datasets: [{
                    label: '# of Downloads',
                    data: [12, 19, 3, 5, 2, 3],
                    backgroundColor: [
                        'rgba(255, 99, 132, 0.2)',
                        'rgba(54, 162, 235, 0.2)',
                        'rgba(255, 206, 86, 0.2)',
                        'rgba(75, 192, 192, 0.2)',
                        'rgba(153, 102, 255, 0.2)',
                        'rgba(255, 159, 64, 0.2)'
                    ],
                    borderColor: [
                        'rgba(255, 99, 132, 1)',
                        'rgba(54, 162, 235, 1)',
                        'rgba(255, 206, 86, 1)',
                        'rgba(75, 192, 192, 1)',
                        'rgba(153, 102, 255, 1)',
                        'rgba(255, 159, 64, 1)'
                    ],
                    borderWidth: 1
                }]
            },
            options: {
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    });
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Semester 4\CS 262\LandoLatest\LoginPage\app\resources\views/backend/dashboard.blade.php ENDPATH**/ ?>