

<?php $__env->startSection('content'); ?>

<style>
    body {
        font-family: "Lexend", sans-serif;
    }

    .profile-img {
        width: 193px;
        height: 193px;
        border-radius: 50%;
        object-fit: cover;
        margin: 0 auto;
        display: block;
        border: 4px solid rgb(255, 255, 255);
    }

    .section-title {
        font-weight: bold;
        text-transform: uppercase;
    }

    .sidebar {
        background-color: #343a40;
        color: white;
        padding: 20px;
        height: 100%;
        width: auto;
    }

    .main-content {
        background-color: #f8f9fa;
        padding: 10px;
        border-radius: 10px;
        flex-grow: 1;
    }

    .title-underline {
        width: 100%;
        height: 1px;
        background-color: #343a40;
        margin-top: 10px;
        margin-bottom: 10px;
    }

    .title-underline-white {
        width: 100%;
        height: 1px;
        background-color: #ffffff;
        margin-top: 10px;
        margin-bottom: 10px;
    }

    h6 {
        font-size: 20px;
        margin-top: 10px;
        margin-bottom: 10px;
    }

    .container-flex {
        display: flex;
        gap: 0;
    }
</style>
<div class="container mt-5">
    <div class="row container-flex">
        <div class="col-md-4 p-0">
            <div class="sidebar">
                <div class="text-center">
                <?php if($userResume->user->profile_pic): ?>
                    <img src="<?php echo e(asset('storage/' . $userResume->user->profile_pic)); ?>" alt="Profile Picture" class="profile-img" />
                <?php else: ?>
                    <p>No profile picture available.</p>
                <?php endif; ?>

                </div>
                <!-- Contact Info -->
                <div class="title-underline-white"></div>
                <div class="contact-info mt-1">
                    <h5>CONTACT</h5>
                    <div class="title-underline-white"></div>
                    <!-- Display phone_number and address from UserCvInfo -->
                    <?php $__currentLoopData = $userResume->cvInfos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cvInfo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($cvInfo->field_name === 'phone_number'): ?>
                            <p><i class="fa fa-phone"></i> <?php echo e($cvInfo->field_value); ?></p>
                        <?php endif; ?>
                        <?php if($cvInfo->field_name === 'email'): ?>
                            <p><i class="fa fa-envelope"></i> <?php echo e($cvInfo->field_value); ?></p>
                        <?php endif; ?>
                        <?php if($cvInfo->field_name === 'address'): ?>
                            <p><i class="fa fa-map-marker"></i> <?php echo e($cvInfo->field_value); ?></p>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

                <!-- Loop through all fields in UserCvInfo -->
                <?php $__currentLoopData = $userResume->cvInfos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cvInfo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if(in_array($cvInfo->field_name, ['skills', 'languages'])): ?>
                        <div class="other-info mt-4">
                            <div class="title-underline-white"></div>
                            <h5><?php echo e(strtoupper($cvInfo->field_name)); ?></h5>
                            <div class="title-underline-white"></div>
                            <!-- Assuming field_value might need special formatting or handling -->
                            <p><?php echo e($cvInfo->field_value); ?></p>
                        </div>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
        <div class="col-md-8 p-0">
            <div class="main-content mt-">
                <!-- name -->
                <div style="display: flex;">
                    <?php $__currentLoopData = $userResume->cvInfos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cvInfo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($cvInfo->field_name === 'first_name'): ?>
                            <h1> 
                             <span id="firstName"><?php echo e($cvInfo->field_value); ?></span>
                            </h1>
                        <?php endif; ?>
                        <?php if($cvInfo->field_name === 'last_name'): ?>
                            <h1>
                             <span id="firstName"><?php echo e($cvInfo->field_value); ?></span>
                            </h1>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <!-- <h3><?php echo e($userResume->cvInfos->where('field_name', 'job_title')->first()->field_value ?? ''); ?></h3> -->
                <div>


                    <!-- WOrk exp 2.0 -->
                    <div class="title-underline"></div>
                    <h5 class="section-title">Work Experience</h5>
                    <div class="title-underline"></div>
                    <h6><?php echo e($userResume->cvInfos->where('field_name', 'job_title')->first()->field_value ?? ''); ?></h6>
                    <h6><?php echo e($userResume->cvInfos->where('field_name', 'qualification')->first()->field_value ?? ''); ?></h6>

                    <!-- education -->
                    <div class="title-underline"></div>
                    <h5 class="section-title">Education</h5>
                    <div class="title-underline"></div>
                    <h6><?php echo e($userResume->cvInfos->where('field_name', 'university')->first()->field_value ?? ''); ?></h6>
                    <h6><?php echo e($userResume->cvInfos->where('field_name', 'qualification')->first()->field_value ?? ''); ?></h6>
                    <h6><?php echo e($userResume->cvInfos->where('field_name', 'major')->first()->field_value ?? ''); ?></h6>
                    <h6><?php echo e($userResume->cvInfos->where('field_name', 'graduation_year')->first()->field_value ?? ''); ?></h6>
                    <?php $__currentLoopData = $userResume->cvInfos->where('field_name', 'education_details'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cvInfo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <p><?php echo e($cvInfo->field_value); ?></p>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <!-- summary -->
                    <div class="title-underline"></div>
                    <h5 class="section-title">Summary</h5>
                    <div class="title-underline"></div>
                    <p><?php echo e($userResume->cvInfos->where('field_name', 'summary')->first()->field_value ?? ''); ?></p>

                    <!-- references -->
                    <div class="title-underline"></div>
                    <h5 class="section-title">References</h5>
                    <div class="title-underline"></div>
                    <ul>
                        <?php $__currentLoopData = $userResume->cvInfos->where('field_name', 'references'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cvInfo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($cvInfo->field_value); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>
</div>
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.2/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<script src="https://kit.fontawesome.com/a076d05399.js"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Semester 4\CS 262\LoginPage 2\LoginPage\app\resources\views/template2.blade.php ENDPATH**/ ?>