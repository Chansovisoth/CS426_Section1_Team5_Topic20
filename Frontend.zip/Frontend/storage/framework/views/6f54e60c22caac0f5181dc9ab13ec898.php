<div class="four" style="background-color: rgb(137, 45, 45); height: 200px; margin-top: 30px;">
        <div class="row">
            <div class="col text-end" style="font-size: 30px; color: white; font-family: 'Times New Roman', Times, serif; padding-top: 40px; line-height: 35px;">SMOS <br><b style="color: orange;">COMPANY</b></div>
            <div class="col" style="text-align: start;">
                <p style="font-size: 19px; font-family: 'Times New Roman', Times, serif; color: white; padding-top: 25px;"><b style="font-size: 22px;">CONTACT</b> <br>smosteaoun@gmail.com <br>085-8888-9999 <br>Contact us</p> 
            </div>
        </div>
    </div><?php /**PATH D:\Projects\UNIVERSITY\PARAGON\YEAR 3\SEMESTER 1\CS 426 - Cloud Computing\CS426_Section1_Team5_Topic20\Frontend\resources\views/layout/footer.blade.php ENDPATH**/ ?>