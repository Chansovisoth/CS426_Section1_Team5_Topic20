<?php $__env->startSection('content'); ?>
<style>

.sidebar{
    background-color: rgb(137, 45, 45);
    color: white;
    
}


.profile-info {
    width: 55%;
}

.info-field {
    margin-bottom: 15px;
    text-align: left;
    
}

.info-field label {
    display: block;
    color: #888;
    margin-bottom: 5px;
    
}

.info-field input {
    width: 100%;
    padding: 8px;
    border: 1px solid #ddd;
    border-radius: 4px;
    background-color: #cecdcd;
}

</style>
    <!-- User-Account -->
    <div style="width: 50%; background-color: rgb(230, 227, 227); margin-left: 25%; margin-top: 3%; border-radius: 20px; border: 1px solid black;">
    <p style="text-align: center; font-size: 30px; font-weight: bold; font-family: 'Times New Roman', Times, serif; color: rgb(255, 166, 0);">User Account</p>
    </div>
<!-- Left -->
<div class="row">
    <div class="col-5">
        <div class="left">
            <img src="camera.png" style="width: 20%; margin-top: 10%; margin-left: 65%;">
            <p style="font-size: 22px; margin-left: 67%;">User Name</p>

        </div>
    </div>
    <!-- Right -->
    <div class="col-7">
        <div class="profile-info" style="margin-top: 7%;">
            <div class="info-field">
                <input type="text" placeholder="Full Name" disabled>
            </div>
            <div class="info-field">

                <input type="text" placeholder="Gender" disabled>
            </div>
            <div class="info-field">
                
                <input type="text" placeholder="Date of Birth" disabled>
            </div>
            <div class="info-field">
                
                <input type="text" placeholder="Email" disabled>
            </div>
            <div class="info-field">
                
                <input type="text" placeholder="Phone Number" disabled>
            </div>
        </div>
    </div>
    
<div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/tangchhannon/Documents/Semester4/CS262/FinalProject/LoginPage/app/resources/views/profile.blade.php ENDPATH**/ ?>