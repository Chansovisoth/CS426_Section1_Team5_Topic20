<?php $__env->startSection('content'); ?>

<style>
    .unique-user-body {
        margin: 0;
        font-family: Arial, sans-serif;
        display: flex;
    }

    .unique-user-sidebar {
        width: 200px;
        background-color: #800000;
        color: white;
        display: flex;
        flex-direction: column;
        align-items: center;
        padding: 20px 0;
    }

    .unique-user-section {
        margin-bottom: 20px;
        color: limegreen;
        font-size: 18px;
        font-weight: bold;
    }

    .unique-user-nav-button {
        background-color: #800000;
        color: white;
        border: none;
        padding: 15px;
        width: 100%;
        text-align: left;
        cursor: pointer;
        font-size: 18px;
    }

    .unique-user-nav-button:hover {
        background-color: #660000;
    }

    .unique-user-main-content {
        flex-grow: 1;
        padding: 20px;
        background-color: #f4f4f4;
    }

    .unique-user-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        background-color: #800000;
        color: limegreen;
        padding: 10px 20px;
    }

    .unique-user-user-button {
        background-color: green;
        color: white;
        border: none;
        padding: 10px 20px;
        cursor: pointer;
        font-size: 18px;
    }

    .unique-user-user-table-container {
        margin: 20px 0;
    }

    .unique-user-user-table {
        width: 100%;
        border-collapse: collapse;
        margin-bottom: 20px;
        background-color: white;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    }

    .unique-user-user-table th,
    .unique-user-user-table td {
        border: 1px solid #ddd;
        padding: 8px;
        text-align: left;
    }

    .unique-user-user-table th {
        background-color: #f4f4f4;
        font-weight: bold;
    }

    .unique-user-user-table tbody tr:hover {
        background-color: #f1f1f1;
    }

    .unique-user-buttons {
        display: flex;
        gap: 10px;
    }

    .unique-user-action-button {
        padding: 10px 20px;
        font-size: 16px;
        cursor: pointer;
    }

    #addUser {
        background-color: #4CAF50;
        color: white;
        border: none;
    }

    #exportList {
        background-color: #008CBA;
        color: white;
        border: none;
    }

    .unique-user-styled-link {
        width: 100px;
        height: 30px;
        text-decoration: none;
        color: rgb(255, 255, 255);
        border-radius: 30px;
        text-align: center;
        font-weight: bold;
        padding-top: 10px;
    }
</style>

<div class="unique-user-body">
    <div class="unique-user-sidebar">
        <aside>
            <ul class="menu">
                <li>
                    <a class="nav-link" href="dashboard" style="color: limegreen; text-decoration: none; font-size: 20px; font-weight: bold;">Dashboard</a>
                </li>
                
                <li>
                    <a class="nav-link" href="template" style="color: limegreen; text-decoration: none; font-size: 20px; font-weight: bold;">Template</a>
                </li>
                
            </ul>
        </aside>
    </div>
    <div class="unique-user-main-content">
        <div class="unique-user-header">
            <h1>USER</h1>
            <a href="user" class="unique-user-styled-link" style="background-color: limegreen;">User</a>
        </div>
        <div class="unique-user-user-table-container">
            <h2>Users</h2>
                
            <table class="unique-user-user-table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Last Name</th>
                        <th>First Name</th>
                        <th>Gender</th>
                        <th>Email</th>
                        <th>Edit</th>
                        <th>Delete User</th>
                    </tr>
                </thead>
               
                <tbody>
                    <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($item->user_id); ?></td>
                            <td><?php echo e($item->first_name); ?></td>
                            <td><?php echo e($item->last_name); ?></td>
                            <td><?php echo e($item->gender); ?></td>
                            <td><?php echo e($item->email); ?></td>
                            <td> <a href="<?php echo e(url('backend/'.$item->user_id.'/edit')); ?>">Edit</a> </td>
                            <td> <a href="<?php echo e(url('backend/'.$item->user_id.'/delete')); ?>">Delete</a> </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
               
            </table>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/tangchhannon/Documents/Semester4/CS262/FinalProject/Last-final-web-display-final-cv/LoginPage/app/resources/views/backend/user.blade.php ENDPATH**/ ?>