document.querySelector('.photo-section button').addEventListener('click', function() {
    document.getElementById('photo-upload').click();
});
