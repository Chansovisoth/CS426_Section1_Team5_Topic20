<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>All CVs</h1>
    <div class="table-responsive">
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>#</th>
                    <th>User</th>
                    <th>Template</th>
                    <th>Created At</th>
                    <th>Updated At</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $cvs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $cv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($index + 1); ?></td>
                    <td><?php echo e($cv->user->name); ?></td>
                    <td>Template <?php echo e($cv->template_id); ?>: <?php echo e($cv->template ? $cv->template->tem_title : 'NONE'); ?></td>
                    <td><?php echo e($cv->created_at); ?></td>
                    <td><?php echo e($cv->updated_at); ?></td>
                    <td><a href="<?php echo e(route('view_resume', ['user_resume_id' => $cv->user_resume_id])); ?>">View</a></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Projects\UNIVERSITY\PARAGON\YEAR 3\SEMESTER 1\CS 426 - Cloud Computing\CS426_Section1_Team5_Topic20\Backend\resources\views/backend/all_cvs.blade.php ENDPATH**/ ?>